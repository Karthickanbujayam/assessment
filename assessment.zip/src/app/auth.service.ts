import { Injectable } from '@angular/core';
import { User } from './user';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  baseUrl = 'https://api.github.com';
  gitUser = null;
  data = null;

  constructor(private httpClient: HttpClient) { }
  
  public login(userInfo: User){
    console.log(userInfo); 
    this.httpClient.get(this.baseUrl + '/users').subscribe((res : any[])=>{
            console.log(res);
            //this.data = res; 
            for(this.gitUser of res){
              console.log(userInfo.username +':'+ this.gitUser.login);
              if(userInfo.username == this.gitUser.login){
                console.log(userInfo.username +':'+ this.gitUser.login);
                localStorage.setItem('ACCESS_TOKEN', "access_token");
                localStorage.setItem('USER_NAME', this.gitUser.login); 
                return true;
              }
            }
    }); 
  }

  public isLoggedIn(){
    return localStorage.getItem('ACCESS_TOKEN') !== null && localStorage.getItem('USER_NAME') !== null;

  }

  public logout(){
    localStorage.removeItem('ACCESS_TOKEN');
    localStorage.removeItem('USER_NAME');
  }

}
